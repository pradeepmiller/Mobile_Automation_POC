package EbayPages;

import org.openqa.selenium.By;

public class productpage {
	
	public static final By addtocart = By.id("com.ebay.mobile:id/button_add_to_cart");
	public static final By viewcart = By.id("com.ebay.mobile:id/action_view_icon");
	public static final By prodprice=By.id("com.ebay.mobile:id/textview_item_price");
	public static final By cartprice=By.id("com.ebay.mobile:id/item_price");
	public static final By checkout=By.id("com.ebay.mobile:id/shopping_cart_checkout");

}
